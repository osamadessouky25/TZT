﻿Imports System.Data
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class insert
    Dim conn As New OleDbConnection("PROVIDER = MICROSOFT.ACE.OLEDB.12.0;DATA SOURCE =" & y & "; EXTENDED PROPERTIES=EXCEL 12.0;")
    Dim dta As OleDbDataAdapter

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        MessageBox.Show("Note" & vbCrLf & "In the Excel sheet" & vbCrLf & "small green arrows (if present) mean that the numbers are formatted as text" & vbCrLf & "To solve this problem" & vbCrLf & "File...Options...Formulas...Uncheck numbers formatting as text")
        End
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        'Dim conn As System.Data.OleDb.OleDbConnection
        Dim cmd As New OleDbCommand("insert into [sheet1$] Values (@serial, @sample,@Ti,@TK,@TC)", conn)
        If TextBox1.Text = "" Then
            MessageBox.Show("Please, insert sample number")
            Exit Sub
        End If
        If TextBox2.Text <> "" Then
            TK = Math.Round(5080 / (6.01 - System.Math.Log10(TextBox2.Text)), 2)
            TC = TK - 273.15
        Else : MessageBox.Show("Please, insert Ti content in ppm")
            TextBox2.Focus()
        End If

        cmd.Parameters.Add("serial", OleDbType.Integer).Value = selectMax() + 1
        cmd.Parameters.Add("sample", OleDbType.VarChar).Value = TextBox1.Text
        cmd.Parameters.Add("Ti", OleDbType.Double).Value = CType(TextBox2.Text, Double)
        cmd.Parameters.Add("TK", OleDbType.Double).Value = TK
        cmd.Parameters.Add("TC", OleDbType.Double).Value = TC
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        grd.Columns.Clear()
        conn.Open()
        Dim dt As New DataTable
        Dim cmd2 As New OleDbCommand("select * from [sheet1$]", conn)
        dt.Load(cmd2.ExecuteReader)
        conn.Close()
        grd.DataSource = dt
        grd.Visible = True

        TextBox1.Text = ""
        TextBox2.Text = ""
        serial.Text = selectMax() + 1
        TextBox1.Focus()
    End Sub

    Private Sub insert_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        grd.Columns.Clear()
        'conn.Open()
        'dta = New OleDbDataAdapter("Select * From [Sheet1$]", conn)
        'Dim cmd2 As New OleDbCommand("select * from [sheet1$]", conn)
        'dta.Load(cmd2.ExecuteReader)
        'conn.Close()
        'grd.DataSource = dta
        'grd.Visible = True
        conn.Open()
        Dim dt As New DataTable
        Dim cmd2 As New OleDbCommand("select * from [sheet1$]", conn)
        dt.Load(cmd2.ExecuteReader)
        conn.Close()
        grd.DataSource = dt
        grd.Visible = True

        
        serial.Text = selectMax() + 1
        TextBox1.Focus()
       


        ' Dim CurrentDate As Date
        ' CurrentDate = Now
        ' If CurrentDate.Year() <> 2020 Then
        'ShowInTaskbar = False
        '   End
        '   End If
        '   If CurrentDate.Month() > 4 Then
        'ShowInTaskbar = False
        '  End
        '  End If
    End Sub

    Private Function selectMax()
        Dim n As Integer
        Dim cmd As New OleDbCommand("select max(serial) from [sheet1$]", conn)
        conn.Open()
        Try
            n = cmd.ExecuteScalar
        Catch
            n = 0
        End Try
        conn.Close()
        Return n
    End Function
End Class