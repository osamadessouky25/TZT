﻿Imports System.Data
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackColor = Color.DarkGray
        Me.TransparencyKey = Color.DarkGray
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.ControlBox = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim appXL As Excel.Application
        Dim wbXl As Excel.Workbook
        Dim shXL As Excel.Worksheet
        Dim raXL As Excel.Range
        appXL = CreateObject("Excel.Application")
        appXL.Visible = False
        wbXl = appXL.Workbooks.Add
        shXL = wbXl.ActiveSheet

        shXL.DisplayRightToLeft = False
        shXL.Name = "sheet1"
        shXL.Cells(1, 1).Value = "serial"
        shXL.Cells(1, 2).Value = "sample"
        shXL.Cells(1, 3).Value = "Ti"
        shXL.Cells(1, 4).Value = "TK"
        shXL.Cells(1, 5).Value = "TC"
        With shXL.Range("A1", "E1")
            .Font.Bold = True
            .Font.Size = 14
            .Font.Name = "arial"

            .VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        End With

        ' raXL = shXL.Range("A1", "E1")
        '  raXL.EntireColumn.AutoFit()


        appXL.UserControl = True
        Dim saveFileDialog As New SaveFileDialog
        saveFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop
        saveFileDialog.Filter = _
        "Excel files (*.xlsx)|*.xlsx|XLS Files (*.xls)|*xls"
        If saveFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim fi As New IO.FileInfo(saveFileDialog.FileName.Trim)


            wbXl.SaveAs(fi.FullName)
            wbXl.Close()
            raXL = Nothing
            shXL = Nothing
            wbXl = Nothing

            appXL.Quit()
            appXL = Nothing
            y = fi.FullName
        Else
            Exit Sub
        End If
        
        Me.Hide()
        insert.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim OpenFileDialog As New OpenFileDialog
        OpenFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop
        OpenFileDialog.Filter = _
        "Excel files (*.xlsx)|*.xlsx|XLS Files (*.xls)|*xls"
        If OpenFileDialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim fi As New IO.FileInfo(OpenFileDialog.FileName)
            y = fi.FullName
        Else
            Exit Sub
        End If
        
        Me.Hide()
        insert.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub
End Class
