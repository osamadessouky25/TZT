﻿Module Module1

    Public TK = 0
    Public TC = 0

    Public y As String
End Module
